nclude <cstdio>
#include <cuda_runtime.h>
#include <cmath>

// Define the RNA sequence length
// #define N 100
// // Define a minimum loop length
// #define MIN_LOOP 1
//
// __device__ int maxVal(int a, int b) {
//     return a > b ? a : b;
//     }
//
//     __device__ bool isPair(char a, char b) {
//         if ((a == 'A' && b == 'U') || (a == 'U' && b == 'A') || (a == 'C' && b == 'G') || (a == 'G' && b == 'C')) {
//                 return true;
//                     }
//                         return false;
//                         }
//
//                         __global__ void nussinovKernel(int table[N][N], char sequence[N]) {
//                             int i = blockIdx.x * blockDim.x + threadIdx.x;
//                                 int j = blockIdx.y * blockDim.y + threadIdx.y;
//
//                                     if (j - i > MIN_LOOP && i < N && j < N) {
//                                             if (isPair(sequence[i], sequence[j])) {
//                                                         table[i][j] = table[i + 1][j - 1] + 1;
//                                                                 }
//
//                                                                         for (int k = i; k < j; k++) {
//                                                                                     table[i][j] = maxVal(table[i][j], table[i][k] + table[k + 1][j]);
//                                                                                             }
//                                                                                                 }
//                                                                                                 }
//
//                                                                                                 int main() {
//                                                                                                     char h_sequence[N] = "AUCGAUCG";    // Example RNA sequence
//                                                                                                         int h_table[N][N] = {{0}};          // Table to store values
//
//                                                                                                             char (*d_sequence)[N];
//                                                                                                                 int (*d_table)[N][N];
//
//                                                                                                                     // Allocate device memory
//                                                                                                                         cudaMalloc((void **)&d_sequence, sizeof(h_sequence));
//                                                                                                                             cudaMalloc((void **)&d_table, sizeof(h_table));
//
//                                                                                                                                 // Copy data to device memory
//                                                                                                                                     cudaMemcpy(d_sequence, h_sequence, sizeof(h_sequence), cudaMemcpyHostToDevice);
//                                                                                                                                         cudaMemcpy(d_table, h_table, sizeof(h_table), cudaMemcpyHostToDevice);
//
//                                                                                                                                             dim3 threadsPerBlock(16, 16);
//                                                                                                                                                 dim3 numBlocks(ceil((float)N / threadsPerBlock.x), ceil((float)N / threadsPerBlock.y));
//
//                                                                                                                                                     // Run the kernel
//                                                                                                                                                         for (int d = MIN_LOOP + 1; d < N; d++) {
//                                                                                                                                                                 for (int i = 0; i < N - d; i++) {
//                                                                                                                                                                             int j = i + d;
//                                                                                                                                                                                         nussinovKernel<<<numBlocks, threadsPerBlock>>>(*d_table, *d_sequence);
//                                                                                                                                                                                                     cudaDeviceSynchronize();
//                                                                                                                                                                                                             }
//                                                                                                                                                                                                                 }
//
//                                                                                                                                                                                                                     // Copy results back to host memory
//                                                                                                                                                                                                                         cudaMemcpy(h_table, d_table, sizeof(h_table), cudaMemcpyDeviceToHost);
//
//                                                                                                                                                                                                                             // ... use h_table for further analysis
//
//                                                                                                                                                                                                                                 // Cleanup device memory
//                                                                                                                                                                                                                                     cudaFree(d_sequence);
//                                                                                                                                                                                                                                         cudaFree(d_table);
//
//                                                                                                                                                                                                                                             return 0;
//                                                                                                                                                                                                                                             }
